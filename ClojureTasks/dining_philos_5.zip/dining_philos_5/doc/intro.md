# Introduction to dining_philos_5

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
